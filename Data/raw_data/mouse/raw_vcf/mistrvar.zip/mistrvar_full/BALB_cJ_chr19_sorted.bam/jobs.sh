#!/bin/bash
/u/home/r/ramayyal/Tools/mistrvar/pipeline/mistrvar.py -p /u/scratch/r/ramayyal/wrappers/mistrvar/mouse/extras/executables/BALB_cJ_chr19_sorted.bam -r chr19.fa --range 0-55699 --worker-id 0 --num-worker 1 --resume sniper 
